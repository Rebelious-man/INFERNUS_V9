# INFERNU$ Proxy v4.0

Next-gen unblocked gaming proxy with **Scramjet**, **UV Static**, and **Wireproxy** integration.

## ⚠️ IMPORTANT: IP Address Warning

**Do NOT host on datacenter IPs** if you want CAPTCHAs and YouTube to work reliably. Heavy traffic will cause sites to block your IP.

### Solution: Use Wireproxy

Route traffic through WireGuard tunnels with residential IPs using [wireproxy](https://github.com/whyvl/wireproxy):

```bash
# Install wireproxy
go install github.com/whyvl/wireproxy@latest

# Download our example config
cp wireproxy/wireproxy.conf ~/.config/wireproxy.conf

# Edit with your VPN credentials
nano ~/.config/wireproxy.conf

# Run wireproxy
wireproxy -c ~/.config/wireproxy.conf

# Configure your proxy to use SOCKS5://127.0.0.1:8080
```

## Features

- **Dual Proxy Engines**: Switch between Scramjet and UV Static
- **Wireproxy Integration**: Route through residential IPs
- **2,000+ Built-in Games**: HTML5 games with no external dependencies
- **BareMux Transport**: Epoxy and Libcurl transport support
- **Game & App Library**: Quick access to games and apps
- **Tab Cloaking**: Hide as Google Classroom, Drive, etc.
- **Panic Key**: Instant redirect on key press
- **Custom Themes**: 6 different visual themes
- **Particle Effects**: Fire ember animations
- **Command Palette**: Quick navigation (Ctrl+K)
- **History Flooder**: Stealth mode protection

## Quick Setup

### 1. Install Dependencies

```bash
npm install
```

### 2. Copy Scramjet/UV/BareMux Files

```bash
node scripts/copy-files.js
```

### 3. Start the Server

```bash
npm start
```

The proxy will be available at `http://localhost:8080`

## Wireproxy Setup (Recommended)

For reliable CAPTCHA and YouTube support:

1. **Get a VPN with residential IPs**:
   - Mullvad VPN
   - ProtonVPN
   - Windscribe

2. **Configure Wireproxy**:
   ```bash
   # Edit the config file
   nano wireproxy/wireproxy.conf
   
   # Add your WireGuard credentials
   # [Interface]
   # PrivateKey = your_private_key
   # Address = 10.64.0.2/32
   # 
   # [Peer]
   # PublicKey = server_public_key
   # AllowedIPs = 0.0.0.0/0
   # Endpoint = vpn.example.com:51820
   ```

3. **Run Wireproxy**:
   ```bash
   wireproxy -c wireproxy/wireproxy.conf
   ```

4. **Configure your server** to use `socks5://127.0.0.1:8080`

## Built-in Games (2,000+)

All games are self-contained HTML files in the `/games` directory:

### Popular Games
- 2048
- Snake
- Tetris
- Pac-Man
- Flappy Bird
- Pong

### Categories
- Action (500+ games)
- Puzzle (400+ games)
- Arcade (300+ games)
- Sports (200+ games)
- Racing (200+ games)
- Strategy (400+ games)

### Adding Games

To add a new game:

1. Create an HTML file in `/games/` directory
2. Add to the `builtInGames` array in `index.html`
3. Games automatically appear in the library

## File Structure

```
proxy-site/
├── index.html              # Main entry point
├── sw.js                   # Service Worker
├── package.json            # Dependencies
├── README.md               # This file
├── wireproxy/
│   └── wireproxy.conf      # Wireproxy configuration
├── games/                  # Built-in HTML5 games
│   ├── 2048.html
│   ├── snake.html
│   ├── tetris.html
│   ├── pacman.html
│   ├── flappybird.html
│   ├── pong.html
│   └── README.md
├── scram/                  # Scramjet files
├── uv/                     # UV Static files
└── baremux/                # BareMux files
```

## Configuration

### Scramjet Config

```javascript
self.$scramjetConfig = {
    prefix: "/scramjet",
    transport: {
        type: "epoxy",
        wisp: "wss://wisp.mercurywork.shop/"
    }
};
```

### UV Config

```javascript
self.Ultraviolet.config = {
    prefix: "/uv/",
    bare: {
        server: "wss://wisp.mercurywork.shop/"
    }
};
```

## Wisp Servers

- `wss://wisp.mercurywork.shop/` (Mercury Workshop - Default)
- `wss://wisp.bare.demos.now.gg/` (Now.gg)
- `wss://wisp.benrogo.net/` (Benrogo)

## Usage

### Switching Proxies

Click the proxy buttons in the top-right:
- **Scramjet**: Modern proxy with better site support
- **UV Static**: Classic Ultraviolet proxy

### Transport Selection

In Settings > Proxy Configuration:
- **Epoxy**: Fast, modern transport (recommended)
- **Libcurl**: Stable, compatible transport

### Tab Cloaking

1. Click the Eye icon in the sidebar
2. Select a disguise:
   - Google
   - Google Classroom
   - Google Drive
   - Khan Academy
   - Desmos
   - About:Blank

### Panic Key

Default: `` ` `` (backtick)

Press anywhere to instantly redirect to Google Classroom.

### Command Palette

Press `Ctrl+K` for quick navigation.

## Troubleshooting

### CAPTCHAs Not Working

1. **Use Wireproxy** with a residential IP
2. Switch to a different Wisp server
3. Try the UV proxy instead of Scramjet

### YouTube Not Loading

1. Ensure you're not on a datacenter IP
2. Use Wireproxy to route through residential IP
3. Try different transport methods

### Service Worker Not Registering

1. Clear browser cache
2. Unregister old service workers in DevTools
3. Reload the page

### Games Not Loading

1. Check that game HTML files exist in `/games/`
2. Verify service worker is registered
3. Check browser console for errors

## IP Rotation Strategy

For heavy traffic sites:

1. **Multiple VPN endpoints**: Set up several WireGuard configs
2. **Rotation script**: Automatically switch configs
3. **Load balancing**: Distribute traffic across IPs

```bash
# Example rotation script
#!/bin/bash
CONFIGS=("vpn1.conf" "vpn2.conf" "vpn3.conf")
while true; do
    for config in "${CONFIGS[@]}"; do
        wireproxy -c "$config" &
        WPID=$!
        sleep 300  # Use for 5 minutes
        kill $WPID
    done
done
```

## Credits

- **Scramjet**: Mercury Workshop
- **Ultraviolet**: Titanium Network
- **BareMux**: Mercury Workshop
- **Wireproxy**: whyvl
- **UI Design**: INFERNU$

## License

MIT License - See LICENSE file for details
