// ============================================
// INFERNU$ SERVICE WORKER
// Scramjet + UV Static Integration
// ============================================

importScripts("/scram/scramjet.all.js");
importScripts("/uv/uv.bundle.js");
importScripts("/uv/uv.config.js");

// Initialize Scramjet Service Worker
const { ScramjetServiceWorker } = $scramjetLoadWorker();
const scramjet = new ScramjetServiceWorker();

// Initialize Ultraviolet
const ultraviolet = new Ultraviolet();

// Service Worker Install Event
self.addEventListener("install", (event) => {
    console.log("[SW] Service Worker installing...");
    
    // Initialize IndexedDB for Scramjet
    event.waitUntil(
        initScramjetDB()
            .then(() => {
                console.log("[SW] IndexedDB initialized successfully");
            })
            .catch(err => {
                console.error("[SW] DB init error (non-fatal):", err);
            })
            .finally(() => {
                return self.skipWaiting();
            })
    );
});

// Initialize Scramjet IndexedDB
let dbInitialized = false;
async function initScramjetDB() {
    if (dbInitialized) return Promise.resolve();
    
    return new Promise((resolve, reject) => {
        // Use higher version to force upgrade if needed
        const request = indexedDB.open("scramjet", 2);
        
        request.onerror = () => {
            console.error("[SW] IndexedDB error:", request.error);
            reject(request.error);
        };
        
        request.onsuccess = () => {
            const db = request.result;
            db.close();
            dbInitialized = true;
            console.log("[SW] IndexedDB initialized successfully");
            resolve();
        };
        
        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            const oldVersion = event.oldVersion;
            
            console.log(`[SW] IndexedDB upgrade: ${oldVersion} -> ${event.newVersion}`);
            
            // Delete existing stores if upgrading
            if (oldVersion > 0) {
                const stores = Array.from(db.objectStoreNames);
                stores.forEach(store => {
                    try {
                        db.deleteObjectStore(store);
                        console.log(`[SW] Deleted old store: ${store}`);
                    } catch (e) {
                        console.warn(`[SW] Could not delete store ${store}:`, e);
                    }
                });
            }
            
            // Create all object stores that Scramjet expects
            const stores = [
                "config",      // Configuration storage
                "cache",       // Response cache
                "storage",     // General storage
                "cookies",     // Cookie storage
                "headers",     // Headers storage
                "metadata",    // Metadata storage
                "rewritten",   // Rewritten content cache
                "original",    // Original content cache
                "sw"           // Service worker storage
            ];
            
            stores.forEach(storeName => {
                try {
                    db.createObjectStore(storeName);
                    console.log(`[SW] Created store: ${storeName}`);
                } catch (e) {
                    console.warn(`[SW] Could not create store ${storeName}:`, e);
                }
            });
            
            console.log("[SW] Created all IndexedDB object stores");
        };
        
        request.onblocked = () => {
            console.warn("[SW] IndexedDB blocked - close other tabs");
        };
    });
}

// Service Worker Activate Event
self.addEventListener("activate", (event) => {
    console.log("[SW] Service Worker activated");
    event.waitUntil(clients.claim());
});

// Fetch Event Handler
self.addEventListener("fetch", (event) => {
    const url = new URL(event.request.url);
    
    // Handle Scramjet requests
    if (url.pathname.startsWith("/scramjet/")) {
        event.respondWith(handleScramjet(event));
        return;
    }
    
    // Handle UV requests
    if (url.pathname.startsWith("/uv/")) {
        event.respondWith(handleUV(event));
        return;
    }
    
    // Default fetch
    event.respondWith(fetch(event.request));
});

// Scramjet Handler
async function handleScramjet(event) {
    try {
        // Ensure DB is initialized before handling
        await initScramjetDB();
        
        // Load config with retry
        let retries = 3;
        while (retries > 0) {
            try {
                await scramjet.loadConfig();
                break;
            } catch (e) {
                retries--;
                if (retries === 0) throw e;
                await new Promise(r => setTimeout(r, 100));
            }
        }
        
        if (scramjet.route(event)) {
            return await scramjet.fetch(event);
        }
        
        return fetch(event.request);
    } catch (error) {
        console.error("[Scramjet] Error:", error);
        return new Response(`
            <html>
            <head><title>Scramjet Error</title></head>
            <body style="background:#111;color:#fff;font-family:sans-serif;padding:40px;">
                <h1 style="color:#ff0044;">Scramjet Error</h1>
                <p>${error.message}</p>
                <p>Try refreshing the page or clearing site data.</p>
                <button onclick="location.reload()" style="padding:10px 20px;background:#ff0044;border:none;color:#fff;cursor:pointer;">Reload</button>
            </body>
            </html>
        `, { 
            status: 500,
            headers: { 'Content-Type': 'text/html' }
        });
    }
}

// UV Handler
async function handleUV(event) {
    try {
        const url = new URL(event.request.url);
        
        // Decode the URL from the path
        const encodedUrl = url.pathname.replace("/uv/service/", "");
        const decodedUrl = Ultraviolet.codec.xor.decode(encodedUrl);
        
        // Create request init options (excluding mode which can't be set to 'navigate')
        const requestInit = {
            method: event.request.method,
            headers: event.request.headers,
            body: event.request.body,
            credentials: event.request.credentials,
            redirect: event.request.redirect,
            cache: event.request.cache,
            referrer: event.request.referrer,
            referrerPolicy: event.request.referrerPolicy,
            integrity: event.request.integrity,
            keepalive: event.request.keepalive
        };
        
        // Only add mode if it's not 'navigate' (which is read-only)
        if (event.request.mode !== 'navigate') {
            requestInit.mode = event.request.mode;
        }
        
        // Create a new request with the decoded URL
        const newRequest = new Request(decodedUrl, requestInit);
        
        // Process through Ultraviolet
        const response = await ultraviolet.fetch(newRequest);
        
        // Process the response
        const processedResponse = await ultraviolet.processResponse(response);
        
        return processedResponse;
    } catch (error) {
        console.error("[UV] Error:", error);
        return new Response(`
            <html>
            <head><title>UV Error</title></head>
            <body style="background:#111;color:#fff;font-family:sans-serif;padding:40px;">
                <h1 style="color:#ff0044;">UV Error</h1>
                <p>${error.message}</p>
                <p>Try using Scramjet instead or refresh the page.</p>
                <button onclick="location.reload()" style="padding:10px 20px;background:#ff0044;border:none;color:#fff;cursor:pointer;">Reload</button>
            </body>
            </html>
        `, { 
            status: 500,
            headers: { 'Content-Type': 'text/html' }
        });
    }
}

// Message Handler for communication with main thread
self.addEventListener("message", (event) => {
    if (event.data === "skipWaiting") {
        self.skipWaiting();
    }
});
