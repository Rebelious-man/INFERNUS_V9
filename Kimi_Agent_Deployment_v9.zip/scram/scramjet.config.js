// ============================================
// Scramjet Configuration
// ============================================

self.$scramjetConfig = {
    // Prefix for Scramjet service routes
    prefix: "/scramjet",
    
    // Files configuration
    files: {
        wasm: "/scram/scramjet.wasm.wasm",
        all: "/scram/scramjet.all.js",
        sync: "/scram/scramjet.sync.js",
    },
    
    // Transport configuration
    transport: {
        // Default transport type
        type: "epoxy",
        
        // Wisp server URL
        wisp: "wss://wisp.mercurywork.shop/",
        
        // Fallback servers
        fallbackWisp: [
            "wss://wisp.bare.demos.now.gg/",
            "wss://wisp.benrogo.net/"
        ]
    },
    
    // Codec configuration
    codec: {
        // Enable encoding
        enabled: true,
        
        // Codec type: "xor", "base64", "plain"
        type: "xor"
    },
    
    // Security settings
    security: {
        // Allow cross-origin requests
        cors: true,
        
        // Allow credentials
        credentials: true
    },
    
    // Logging
    logging: {
        // Enable debug logging
        debug: true,
        
        // Log level: "verbose", "debug", "info", "warn", "error"
        level: "debug"
    }
};
