// ============================================
// Setup Script for INFERNU$ Proxy
// Copies Scramjet, UV, and BareMux files after npm install
// ============================================

const fs = require('fs');
const path = require('path');

console.log('========================================');
console.log('INFERNU$ Proxy Setup');
console.log('========================================\n');

// File mappings
const filesToCopy = [
    // Scramjet files
    {
        source: 'node_modules/@mercuryworkshop/scramjet/dist/scramjet.all.js',
        dest: 'scram/scramjet.all.js',
        required: true
    },
    {
        source: 'node_modules/@mercuryworkshop/scramjet/dist/scramjet.wasm.wasm',
        dest: 'scram/scramjet.wasm.wasm',
        required: true
    },
    {
        source: 'node_modules/@mercuryworkshop/scramjet/dist/scramjet.sync.js',
        dest: 'scram/scramjet.sync.js',
        required: false
    },
    // UV files
    {
        source: 'node_modules/@titaniumnetwork-dev/ultraviolet/dist/uv.bundle.js',
        dest: 'uv/uv.bundle.js',
        required: true
    },
    {
        source: 'node_modules/@titaniumnetwork-dev/ultraviolet/dist/uv.handler.js',
        dest: 'uv/uv.handler.js',
        required: false
    },
    {
        source: 'node_modules/@titaniumnetwork-dev/ultraviolet/dist/uv.client.js',
        dest: 'uv/uv.client.js',
        required: false
    },
    // BareMux files
    {
        source: 'node_modules/@mercuryworkshop/bare-mux/dist/index.js',
        dest: 'baremux/index.js',
        required: true
    },
    {
        source: 'node_modules/@mercuryworkshop/bare-mux/dist/worker.js',
        dest: 'baremux/worker.js',
        required: true
    }
];

let copied = 0;
let failed = 0;
let skipped = 0;

filesToCopy.forEach(file => {
    const sourcePath = path.join(__dirname, '..', file.source);
    const destPath = path.join(__dirname, '..', file.dest);
    
    // Check if source exists
    if (!fs.existsSync(sourcePath)) {
        if (file.required) {
            console.log(`❌ MISSING (Required): ${file.source}`);
            failed++;
        } else {
            console.log(`⚠️  MISSING (Optional): ${file.source}`);
            skipped++;
        }
        return;
    }
    
    // Ensure destination directory exists
    const destDir = path.dirname(destPath);
    if (!fs.existsSync(destDir)) {
        fs.mkdirSync(destDir, { recursive: true });
    }
    
    // Copy file
    try {
        fs.copyFileSync(sourcePath, destPath);
        console.log(`✅ Copied: ${file.source} → ${file.dest}`);
        copied++;
    } catch (err) {
        console.log(`❌ Error copying ${file.source}: ${err.message}`);
        failed++;
    }
});

console.log('\n========================================');
console.log('Setup Complete!');
console.log('========================================');
console.log(`Copied: ${copied}`);
console.log(`Skipped (optional): ${skipped}`);
console.log(`Failed: ${failed}`);

if (failed > 0) {
    console.log('\n⚠️  Some required files failed to copy.');
    console.log('Make sure you have run: npm install');
    process.exit(1);
} else {
    console.log('\n✨ All files copied successfully!');
    console.log('Run "npm start" to start the server.');
    process.exit(0);
}
