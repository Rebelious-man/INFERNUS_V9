# INFERNU$ Built-in Games

This directory contains 2,000+ HTML5 games that run directly in the browser without external dependencies.

## Available Games

### Popular Games
- **2048** - Classic tile-merging puzzle game
- **Snake** - Retro snake game with neon styling
- **Tetris** - Full-featured Tetris clone
- **Pac-Man** - Arcade classic with ghosts and power pellets
- **Flappy Bird** - Infamous side-scrolling game
- **Pong** - Original table tennis game

### Action Games
- Zombie Shooter
- Space Invaders
- Asteroids
- Galaga
- DOOM (browser port)
- Quake (browser port)

### Puzzle Games
- Sudoku
- Crossword
- Word Search
- Mahjong
- Solitaire
- Minesweeper
- Chess
- Checkers
- Connect 4
- Rubik's Cube

### Arcade Games
- Breakout
- Pinball
- Frogger
- Donkey Kong
- Mario Bros
- Sonic
- Street Fighter

### Sports Games
- Basketball
- Soccer
- Tennis
- Golf
- Bowling
- 8-Ball Pool
- Skateboarding
- Snowboarding

### Racing Games
- Mario Kart
- Need for Speed
- Burnout
- F-Zero
- Wipeout

### Strategy Games
- Tower Defense
- Plants vs Zombies
- Age of War
- Bloons TD
- Civilization
- Risk

## Adding New Games

To add a new game:

1. Create an HTML file in this directory (e.g., `mygame.html`)
2. Add the game to the `builtInGames` array in `index.html`:

```javascript
{
    id: 'mygame',
    name: 'My Game',
    icon: 'ri-gamepad-line',
    category: 'action',
    color: '#FF0000',
    type: 'builtin'
}
```

3. The game will automatically appear in the game library

## Game Categories

- `popular` - Most played games
- `action` - Action and shooting games
- `puzzle` - Brain teasers and puzzles
- `arcade` - Classic arcade games
- `sports` - Sports simulations
- `racing` - Racing and driving games
- `strategy` - Strategy and tower defense

## Technical Notes

- All games are self-contained HTML files
- No external dependencies required
- Games save high scores to localStorage
- Responsive design for mobile devices
- Touch controls supported where applicable
